package com.rrhh.reclutamiento_sevice.application.dto;

public record AfpDto(
        Long id,
        String descripcion
){

}
