package com.rrhh.reclutamiento_sevice.application.dto;

public record DireccionDto(
        String direccion,
        String distrito,
        String provincia,
        String departamento,
        String pais
) {}
