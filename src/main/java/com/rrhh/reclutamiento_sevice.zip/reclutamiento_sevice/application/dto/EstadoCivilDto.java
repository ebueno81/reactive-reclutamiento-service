package com.rrhh.reclutamiento_sevice.application.dto;

public record EstadoCivilDto(Long id, String descripcion) {
}
