package com.rrhh.reclutamiento_sevice.application.dto;

public record TipoDocumentoDto(Long id, String descripcion) {
}
