package com.rrhh.reclutamiento_sevice.application.dto;

public record SexoDto (
        Long id,
        String descripcion
){

}
