package com.rrhh.reclutamiento_sevice.application.dto;

public record HijoDto(
        String nombre,
        Integer edad
) {}
