package com.rrhh.reclutamiento_sevice.application.dto;

public record GradoInstruccionDto(Long id, String descripcion) {
}
