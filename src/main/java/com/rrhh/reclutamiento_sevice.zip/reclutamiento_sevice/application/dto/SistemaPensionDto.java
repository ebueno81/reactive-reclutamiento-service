package com.rrhh.reclutamiento_sevice.application.dto;

public record SistemaPensionDto(
        Long id,
        String descripcion
){

}
