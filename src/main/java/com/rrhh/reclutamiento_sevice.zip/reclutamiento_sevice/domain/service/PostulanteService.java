package com.rrhh.reclutamiento_sevice.domain.service;

public class PostulanteService {
}
