package com.rrhh.reclutamiento_sevice.domain.model;

public record TipoDocumento(
        Long id,
        String descripcion
) {
}
