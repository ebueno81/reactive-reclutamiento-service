package com.rrhh.reclutamiento_sevice.domain.model;

public record EstadoCivil (
        Long id,
        String descripcion
){
}
