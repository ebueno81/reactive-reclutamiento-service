package com.rrhh.reclutamiento_sevice.domain.model;

public record GradoInstruccion(
        Long id,
        String descripcion
) {
}
