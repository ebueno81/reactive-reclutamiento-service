package com.rrhh.reclutamiento_sevice.domain.model;

public record Sexo (
        Long id,
        String descripcion
) {
}
