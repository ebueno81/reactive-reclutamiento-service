package com.rrhh.reclutamiento_sevice.domain.model;

public record Afp(
        Long id,
        String descripcion
) {
}
