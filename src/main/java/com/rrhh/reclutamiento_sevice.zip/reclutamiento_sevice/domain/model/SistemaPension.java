package com.rrhh.reclutamiento_sevice.domain.model;

public record SistemaPension(
        Long id,
        String descripcion
) {
}
